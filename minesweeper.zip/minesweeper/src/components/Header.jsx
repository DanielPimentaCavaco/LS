import React from "react";

function Header() {
  return (
    <header>
      <h1 className="title">Minesweeper</h1>
    </header>
  );
}

export default Header;